// Exact-ROM profiles. Companion versions are independent of the builder version.
globalThis.COMPANION_PROFILES=[
  {
    "id": "fe7-vietnamese",
    "name": "FE7 Vietnamese",
    "nameVi": "FE7 Việt hóa",
    "code": "AE7E",
    "crc32": "32CD990D",
    "api": "FE7PublicPrep",
    "template": "FE7_TEMPLATE",
    "runtime": "FE7_RUNTIME_TEMPLATE",
    "native": "FE7_NATIVE_DESIGN",
    "output": "FE7-Vietnamese-Companion-1.0.0"
  },
  {
    "id": "fe6-remastered",
    "name": "FE6 Vietnamese",
    "nameVi": "FE6 Việt hóa",
    "code": "BE8E",
    "crc32": "BD53D5F3",
    "api": "FE6PublicPrep",
    "template": "FE6_TEMPLATE",
    "runtime": "FE6_RUNTIME_TEMPLATE",
    "native": "FE6_NATIVE_DESIGN",
    "output": "FE6-Vietnamese-Companion-1.0.0"
  },
  {
    "id": "fe8-vietnamese",
    "name": "FE8 Vietnamese",
    "nameVi": "FE8 Việt hóa",
    "code": "BE8E",
    "crc32": "3CD932D7",
    "api": "FE8PublicPrep",
    "template": "FE8_TEMPLATE",
    "runtime": "FE8_RUNTIME_TEMPLATE",
    "native": "FE8_NATIVE_DESIGN",
    "output": "FE8-Vietnamese-Companion-1.0.0"
  }
];
